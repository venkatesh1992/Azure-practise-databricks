# Databricks notebook source
# MAGIC %sql
# MAGIC create database if not exists f1_deltalake
# MAGIC location "/mnt/formula1dlven/delta-lake"

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop database if exists f1_deltalake cascade;

# COMMAND ----------

results_df = spark.read.option("inferSchema",True).json("/mnt/formula1dlven/raw/2021-03-28/results.json")

# COMMAND ----------

display(results_df)

# COMMAND ----------

#df.write.format("delta").mode("overwrite").save("/delta/events")
results_df.write.format("delta").mode("overwrite").saveAsTable("f1_deltalake.results_managed")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.results_managed;

# COMMAND ----------

results_df.write.format("delta").mode("overwrite").save("/mnt/formula1dlven/delta-lake/results_external")

# COMMAND ----------

# MAGIC %sql
# MAGIC create table f1_deltalake.results_external
# MAGIC using delta
# MAGIC location "/mnt/formula1dlven/delta-lake/results_external";

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.results_external;

# COMMAND ----------

results_external_df = spark.read.format("delta").load("/mnt/formula1dlven/delta-lake/results_external")

# COMMAND ----------

display(results_external_df)

# COMMAND ----------

results_external_df.write.format("delta").partitionBy("constructorId").saveAsTable("f1_deltalake.results_managed_partitioned")

# COMMAND ----------

# MAGIC %sql
# MAGIC show partitions f1_deltalake.results_managed_partitioned;

# COMMAND ----------

# MAGIC %md
# MAGIC # updates and deletes

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.results_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC update f1_deltalake.results_managed
# MAGIC set points = 11-position
# MAGIC where position <=10

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.results_managed;

# COMMAND ----------

from delta.tables import DeltaTable

deltaTable = DeltaTable.forPath(spark, "/mnt/formula1dlven/delta-lake/results_managed")

deltaTable.update("position <=10", { "points": "21-position" } )   # predicate using SQL formatted string

#deltaTable.update(col("eventType") == "clck", { "eventType": lit("click") } )

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.results_managed;

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM f1_deltalake.results_managed WHERE position >10

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.results_managed;

# COMMAND ----------

from delta.tables import DeltaTable


deltaTable = DeltaTable.forPath(spark,  "/mnt/formula1dlven/delta-lake/results_managed")

deltaTable.delete("points = 0")        # predicate using SQL formatted string

#deltaTable.delete(col("date") < "2017-01-01")   # predicate using Spark SQL functions

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.results_managed;

# COMMAND ----------

# MAGIC %md
# MAGIC # upsert using merge

# COMMAND ----------

drivers_day1_df = spark.read \
.option("inferSchema",True) \
.json("/mnt/formula1dlven/raw/2021-03-28/drivers.json") \
.filter("driverId <= 10") \
.select("driverId","dob","name.forename","name.surname")

# COMMAND ----------

display(drivers_day1_df)

# COMMAND ----------

drivers_day1_df.createOrReplaceTempView("drivers_day1")

# COMMAND ----------

from pyspark.sql.functions import upper
drivers_day2_df = spark.read \
.option("inferSchema",True) \
.json("/mnt/formula1dlven/raw/2021-03-28/drivers.json") \
.filter("driverId between 6 and 15") \
.select("driverId","dob",upper("name.forename").alias("forename"),upper("name.surname").alias("surname"))

# COMMAND ----------

display(drivers_day2_df)

# COMMAND ----------

drivers_day2_df.createOrReplaceTempView("drivers_day2")

# COMMAND ----------

from pyspark.sql.functions import upper
drivers_day3_df = spark.read \
.option("inferSchema",True) \
.json("/mnt/formula1dlven/raw/2021-03-28/drivers.json") \
.filter("driverId between 1 and 5 or driverId between 16 and 20") \
.select("driverId","dob",upper("name.forename").alias("forename"),upper("name.surname").alias("surname"))

# COMMAND ----------

display(drivers_day3_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists f1_deltalake.drivers_merge(
# MAGIC driverId int,
# MAGIC dob date,
# MAGIC forename string,
# MAGIC surname string,
# MAGIC createdDate date,
# MAGIC updatedDate date
# MAGIC )
# MAGIC using delta;

# COMMAND ----------

# MAGIC %md
# MAGIC #Day1

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_deltalake.drivers_merge tgt
# MAGIC USING drivers_day1 upd
# MAGIC ON tgt.driverId = upd.driverId
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET tgt.dob = upd.dob, tgt.forename = upd.forename, tgt.surname = upd.surname, tgt.updatedDate = current_timestamp
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (driverId,dob,forename,surname,createdDate) VALUES (driverId,dob,forename,surname,current_timestamp)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.drivers_merge;

# COMMAND ----------

# MAGIC %md
# MAGIC #Day2

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_deltalake.drivers_merge tgt
# MAGIC USING drivers_day2 upd
# MAGIC ON tgt.driverId = upd.driverId
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET tgt.dob = upd.dob, tgt.forename = upd.forename, tgt.surname = upd.surname, tgt.updatedDate = current_timestamp
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (driverId,dob,forename,surname,createdDate) VALUES (driverId,dob,forename,surname,current_timestamp)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.drivers_merge;

# COMMAND ----------

# MAGIC %md
# MAGIC #Day3

# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql.functions import current_timestamp

deltaTable = DeltaTable.forPath(spark, "/mnt/formula1dlven/delta-lake/drivers_merge")

deltaTable.alias("tgt").merge(
    drivers_day3_df.alias("upd"),
    "tgt.driverId = upd.driverId") \
  .whenMatchedUpdate(set = { "dob" : "upd.dob","forename" : "upd.forename","surname" : "upd.surname","updatedDate" : "current_timestamp()" } ) \
  .whenNotMatchedInsert(values =
    {
      "driverId" : "upd.driverId","dob" : "upd.dob","forename" : "upd.forename","surname" : "upd.surname","createdDate" : "current_timestamp()"
    }
  ) \
  .execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.drivers_merge;

# COMMAND ----------

# MAGIC %md
# MAGIC ##1.History & Versioning
# MAGIC ##2.Time travel
# MAGIC ##3.vaccum

# COMMAND ----------

# MAGIC %sql
# MAGIC desc history f1_deltalake.drivers_merge;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.drivers_merge version as of 1;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.drivers_merge version as of 2;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.drivers_merge timestamp as of '2021-08-06T06:25:32.000+0000';

# COMMAND ----------

df = spark.read.format("delta").option("versionAsOf",1).load("/mnt/formula1dlven/delta-lake/drivers_merge")

# COMMAND ----------

display(df)

# COMMAND ----------

df = spark.read.format("delta").option("timestampAsOf","2021-08-06T06:28:33.000+0000").load("/mnt/formula1dlven/delta-lake/drivers_merge")

# COMMAND ----------

display(df)

# COMMAND ----------

df = spark.read.format("delta").option("timestampAsOf","2021-08-06T06:28:33.000+0000").table("f1_deltalake.drivers_merge")

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC vacuum f1_deltalake.drivers_merge;

# COMMAND ----------

# MAGIC %md
# MAGIC we are able to see the data after vacuum also, as data retention policy is 7 days. we can set it it to 0 hours and can check its working

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.drivers_merge timestamp as of '2021-08-06T06:25:32.000+0000';

# COMMAND ----------

# MAGIC %sql
# MAGIC vacuum f1_deltalake.drivers_merge retain 0 hours;

# COMMAND ----------

# MAGIC %sql
# MAGIC set spark.databricks.delta.retentionDurationCheck.enabled = false;
# MAGIC vacuum f1_deltalake.drivers_merge retain 0 hours;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.drivers_merge timestamp as of '2021-08-06T06:25:32.000+0000';

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.drivers_merge;

# COMMAND ----------

# MAGIC %sql
# MAGIC desc history f1_deltalake.drivers_merge;

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from f1_deltalake.drivers_merge where driverId=1;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.drivers_merge;

# COMMAND ----------

# MAGIC %sql
# MAGIC desc history f1_deltalake.drivers_merge;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.drivers_merge version as of 3;

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into f1_deltalake.drivers_merge tgt
# MAGIC using f1_deltalake.drivers_merge version as of 3 src
# MAGIC on (tgt.driverId = src.driverId)
# MAGIC when not matched then
# MAGIC insert *;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_deltalake.drivers_merge;

# COMMAND ----------

# MAGIC %sql
# MAGIC desc history f1_deltalake.drivers_merge;

# COMMAND ----------

# MAGIC %md
# MAGIC #Transaction logs

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists f1_deltalake.drivers_txn(
# MAGIC driverId int,
# MAGIC dob date,
# MAGIC forename string,
# MAGIC surname string,
# MAGIC createdDate date,
# MAGIC updatedDate date
# MAGIC )
# MAGIC using delta;

# COMMAND ----------

# MAGIC %sql
# MAGIC desc history f1_deltalake.drivers_txn;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT into f1_deltalake.drivers_txn
# MAGIC SELECT * from f1_deltalake.drivers_merge WHERE driverId=1;

# COMMAND ----------

# MAGIC %sql
# MAGIC desc history f1_deltalake.drivers_txn;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT into f1_deltalake.drivers_txn
# MAGIC SELECT * from f1_deltalake.drivers_merge WHERE driverId=2;

# COMMAND ----------

# MAGIC %sql
# MAGIC desc history f1_deltalake.drivers_txn;

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from f1_deltalake.drivers_txn
# MAGIC WHERE driverId=1;

# COMMAND ----------

# MAGIC %sql
# MAGIC desc history f1_deltalake.drivers_txn;

# COMMAND ----------

for driverId in range(3,20):
  spark.sql(f"""INSERT into f1_deltalake.drivers_txn
SELECT * from f1_deltalake.drivers_merge WHERE driverId={driverId}""")

# COMMAND ----------

# MAGIC %sql
# MAGIC desc history f1_deltalake.drivers_txn;

# COMMAND ----------

# MAGIC %md
# MAGIC convert parquet to Delta

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists f1_deltalake.drivers_convert_to_delta(
# MAGIC driverId int,
# MAGIC dob date,
# MAGIC forename string,
# MAGIC surname string,
# MAGIC createdDate date,
# MAGIC updatedDate date
# MAGIC )
# MAGIC using parquet;

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT into f1_deltalake.drivers_convert_to_delta
# MAGIC SELECT * from f1_deltalake.drivers_merge;

# COMMAND ----------

# MAGIC %sql
# MAGIC convert to delta f1_deltalake.drivers_convert_to_delta;

# COMMAND ----------

df=spark.table("f1_deltalake.drivers_convert_to_delta")

# COMMAND ----------

df.write.parquet("/mnt/formula1dlven/delta-lake/drivers_convert_to_delta_new")

# COMMAND ----------

# MAGIC %sql
# MAGIC convert to delta parquet.`/mnt/formula1dlven/delta-lake/drivers_convert_to_delta_new`

# COMMAND ----------


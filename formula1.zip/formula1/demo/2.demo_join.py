# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

races_df = spark.read.parquet(f"{processed_folder_path}/races").filter("race_year=2019").withColumnRenamed("name","race_name")

# COMMAND ----------

circuits_df = spark.read.parquet(f"{processed_folder_path}/circuits").withColumnRenamed("name","circuit_name").filter("circuit_id<70")

# COMMAND ----------

display(races_df)

# COMMAND ----------

display(circuits_df)

# COMMAND ----------

races_circuits_df = circuits_df.join(races_df,circuits_df.circuit_id==races_df.circuit_id,"inner") \
.select(circuits_df.circuit_name,circuits_df.location,circuits_df.race_country,races_df.race_name,races_df.round)

# COMMAND ----------

display(races_circuits_df)

# COMMAND ----------

races_circuits_df.select("circuit_name").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ###Left Outer join

# COMMAND ----------

races_circuits_df = circuits_df.join(races_df,circuits_df.circuit_id==races_df.circuit_id,"left") \
.select(circuits_df.circuit_name,circuits_df.location,circuits_df.race_country,races_df.race_name,races_df.round)
display(races_circuits_df)

# COMMAND ----------

races_circuits_df = circuits_df.join(races_df,circuits_df.circuit_id==races_df.circuit_id,"right") \
.select(circuits_df.circuit_name,circuits_df.location,circuits_df.race_country,races_df.race_name,races_df.round)
display(races_circuits_df)

# COMMAND ----------

races_circuits_df = circuits_df.join(races_df,circuits_df.circuit_id==races_df.circuit_id,"full") \
.select(circuits_df.circuit_name,circuits_df.location,circuits_df.race_country,races_df.race_name,races_df.round)
display(races_circuits_df)

# COMMAND ----------

races_circuits_df = circuits_df.join(races_df,circuits_df.circuit_id==races_df.circuit_id,"semi") \
.select(circuits_df.circuit_name,circuits_df.location,circuits_df.race_country)
display(races_circuits_df)

# COMMAND ----------

races_circuits_df = circuits_df.join(races_df,circuits_df.circuit_id==races_df.circuit_id,"anti") \
.select(circuits_df.circuit_name,circuits_df.location,circuits_df.race_country)
display(races_circuits_df)

# COMMAND ----------

races_circuits_df = circuits_df.crossJoin(races_df) \
.select(circuits_df.circuit_name,circuits_df.location,circuits_df.race_country,races_df.race_name,races_df.round)
display(races_circuits_df)

# COMMAND ----------

races_circuits_df.count()

# COMMAND ----------


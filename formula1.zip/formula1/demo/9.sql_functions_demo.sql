-- Databricks notebook source
select * from f1_processed.drivers;

-- COMMAND ----------

select *,concat(driver_ref,'-',code) as new_driver_ref
from f1_processed.drivers;

-- COMMAND ----------

select *,split(name,' ')
from f1_processed.drivers;

-- COMMAND ----------

select *,split(name,' ')[0] as forename,split(name,' ')[1] as surname
from f1_processed.drivers;

-- COMMAND ----------

select *,current_timestamp
from f1_processed.drivers;

-- COMMAND ----------

select *,date_format(dob,'dd-MM-yyyy') as new_dob
from f1_processed.drivers;

-- COMMAND ----------

select *,date_add(dob,1) as new_dob
from f1_processed.drivers;

-- COMMAND ----------

select count(*)
from f1_processed.drivers;

-- COMMAND ----------

select max(dob)
from f1_processed.drivers;

-- COMMAND ----------

select name
from f1_processed.drivers
where dob = '2000-05-11';

-- COMMAND ----------

select count(*)
from f1_processed.drivers
where nationality='British';

-- COMMAND ----------

select nationality,count(*)
from f1_processed.drivers
group by nationality

-- COMMAND ----------

select nationality,count(*) as cnt
from f1_processed.drivers
group by nationality
order by cnt desc;

-- COMMAND ----------

select nationality,count(*) as cnt
from f1_processed.drivers
group by nationality
having cnt >= 100
order by cnt desc;

-- COMMAND ----------

select nationality,name, dob,rank() over(partition by nationality order by dob desc) as age_rank
from f1_processed.drivers
order by nationality,age_rank;

-- COMMAND ----------


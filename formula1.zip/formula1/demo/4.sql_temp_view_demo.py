# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

race_results_df = spark.read.parquet(f"{presentation_folder_path}/race_results")

# COMMAND ----------

race_results_df.createOrReplaceTempView("race_results_vw")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from race_results_vw
# MAGIC where race_year=2020

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(1) from race_results_vw
# MAGIC where race_year=2020

# COMMAND ----------

df = spark.sql("select * from race_results_vw where race_year=2019")

# COMMAND ----------

display(df)

# COMMAND ----------

p_year=2020

# COMMAND ----------

df1 = spark.sql(f"select * from race_results_vw where race_year={p_year}")
display(df1)

# COMMAND ----------


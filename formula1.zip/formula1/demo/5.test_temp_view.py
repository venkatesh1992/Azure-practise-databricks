# Databricks notebook source
# MAGIC %sql
# MAGIC select * from race_results_vw

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.race_results_gvw

# COMMAND ----------


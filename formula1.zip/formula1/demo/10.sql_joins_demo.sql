-- Databricks notebook source
desc f1_presentation.driver_standings;

-- COMMAND ----------

select * from f1_presentation.driver_standings;

-- COMMAND ----------

create or replace temp view driver_standings_2018_vw
as
select race_year,driver_name,team,total_points,wins,rank
from f1_presentation.driver_standings
where race_year='2018';

-- COMMAND ----------

select * from driver_standings_2018_vw;

-- COMMAND ----------

create or replace temp view driver_standings_2020_vw
as
select race_year,driver_name,team,total_points,wins,rank
from f1_presentation.driver_standings
where race_year='2020';

-- COMMAND ----------

select * from driver_standings_2020_vw;

-- COMMAND ----------

select * from driver_standings_2018_vw d_2018 
inner join driver_standings_2020_vw d_2020
on (d_2018.driver_name=d_2020.driver_name);

-- COMMAND ----------

select * from driver_standings_2018_vw d_2018 
left join driver_standings_2020_vw d_2020
on (d_2018.driver_name=d_2020.driver_name);

-- COMMAND ----------

select * from driver_standings_2018_vw d_2018 
right join driver_standings_2020_vw d_2020
on (d_2018.driver_name=d_2020.driver_name);

-- COMMAND ----------

select * from driver_standings_2018_vw d_2018 
full join driver_standings_2020_vw d_2020
on (d_2018.driver_name=d_2020.driver_name);

-- COMMAND ----------

select * from driver_standings_2018_vw d_2018 
semi join driver_standings_2020_vw d_2020
on (d_2018.driver_name=d_2020.driver_name);

-- COMMAND ----------

select * from driver_standings_2018_vw d_2018 
anti join driver_standings_2020_vw d_2020
on (d_2018.driver_name=d_2020.driver_name);

-- COMMAND ----------

select * from driver_standings_2018_vw d_2018 
cross join driver_standings_2020_vw d_2020

-- COMMAND ----------


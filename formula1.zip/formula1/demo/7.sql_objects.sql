-- Databricks notebook source
create database demo;

-- COMMAND ----------

create database if not exists demo;

-- COMMAND ----------

show databases;

-- COMMAND ----------

describe database demo;

-- COMMAND ----------

desc database demo;

-- COMMAND ----------

desc database default;

-- COMMAND ----------

desc database extended demo;

-- COMMAND ----------

select current_database();

-- COMMAND ----------

show tables;

-- COMMAND ----------

show tables in demo;

-- COMMAND ----------

use demo;

-- COMMAND ----------

select current_database();

-- COMMAND ----------

show tables;

-- COMMAND ----------

show tables in default;

-- COMMAND ----------

-- MAGIC %run "../includes/configuration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df = spark.read.parquet(f"{presentation_folder_path}/race_results")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").saveAsTable("demo.race_results_python")

-- COMMAND ----------

show tables in demo;

-- COMMAND ----------

select * from demo.race_results_python
where race_year=2020;

-- COMMAND ----------

desc extended demo.race_results_python;

-- COMMAND ----------

create table demo.race_results_sql
as
select * from demo.race_results_python
where race_year=2020;

-- COMMAND ----------

show tables in demo;

-- COMMAND ----------

select * from demo.race_results_sql;

-- COMMAND ----------

desc extended demo.race_results_sql;

-- COMMAND ----------

drop table demo.race_results_sql;

-- COMMAND ----------

show tables in demo;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").option("path",f"{presentation_folder_path}/race_results_ext_py") \
-- MAGIC .saveAsTable("demo.race_results_ext_py")

-- COMMAND ----------

show tables in demo;

-- COMMAND ----------

desc extended demo.race_results_ext_py;

-- COMMAND ----------

show create table demo.race_results_ext_py;

-- COMMAND ----------

CREATE TABLE `demo`.`race_results_ext_sql` ( `race_year` INT, `race_name` STRING, `race_date` TIMESTAMP, `circuit_location` STRING, `driver_name` STRING, `driver_number` INT, `driver_nationality` STRING, `team` STRING, `grid` INT, `fastest_lap` INT, `race_time` STRING, `points` FLOAT, `position` INT, `created_date` TIMESTAMP) USING parquet LOCATION 'dbfs:/mnt/formula1dlven/presentation/race_results_ext_sql';

-- COMMAND ----------

desc extended `demo`.`race_results_ext_sql`;

-- COMMAND ----------

insert into table demo.race_results_ext_sql select * from demo.race_results_ext_py where race_year=2020;

-- COMMAND ----------

select * from `demo`.`race_results_ext_sql`;

-- COMMAND ----------

show tables in demo;

-- COMMAND ----------

drop table `demo`.`race_results_ext_sql`;

-- COMMAND ----------

show tables in demo;

-- COMMAND ----------

create or replace temp view race_results_vw as select * from demo.race_results_python where race_year=2018;

-- COMMAND ----------

select * from race_results_vw;

-- COMMAND ----------

create or replace global temp view race_results_gvw as select * from demo.race_results_python where race_year=2018;

-- COMMAND ----------

select * from global_temp.race_results_gvw;

-- COMMAND ----------

show tables in global_temp;

-- COMMAND ----------

create or replace view race_results_pv as select * from demo.race_results_python where race_year=2000;

-- COMMAND ----------

show tables in demo;

-- COMMAND ----------

select current_database();

-- COMMAND ----------


# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

race_results_df  = spark.read.parquet(f"{presentation_folder_path}/race_results")

# COMMAND ----------

display(race_results_df)

# COMMAND ----------

demo_df = race_results_df.filter("race_year == 2020")

# COMMAND ----------

display(demo_df)

# COMMAND ----------

from pyspark.sql.functions import count,countDistinct,sum

# COMMAND ----------

demo_df.select(count("*")).show()

# COMMAND ----------

demo_df.select(count("race_name")).show()

# COMMAND ----------

demo_df.select(countDistinct("race_name")).show()

# COMMAND ----------

demo_df.select(sum("points")).show()

# COMMAND ----------

demo_df.filter("driver_name == 'Lewis Hamilton'").select(sum("points")).show()

# COMMAND ----------

demo_df.filter("driver_name == 'Lewis Hamilton'").select(countDistinct("race_name"),sum("points")).show()

# COMMAND ----------

demo_df.filter("driver_name == 'Lewis Hamilton'").select(countDistinct("race_name").alias("number_of_races"),sum("points").alias("total_points")).show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Group by

# COMMAND ----------

demo_df \
.groupBy("driver_name") \
.agg(sum("points").alias("total_points"),countDistinct("race_name").alias("number_of_races")) \
.show()

# COMMAND ----------

from pyspark.sql.functions import desc

# COMMAND ----------

demo_df \
.groupBy("driver_name") \
.agg(sum("points").alias("total_points"),countDistinct("race_name").alias("number_of_races")) \
.orderBy(desc("total_points")) \
.show()

# COMMAND ----------

demo_df.createOrReplaceTempView("demo")

# COMMAND ----------

d1 = spark.sql("select * from demo")
display(d1)

# COMMAND ----------

d2 = spark.sql("""select driver_name, sum(points) as total_points,count(distinct race_name) as number_of_races from demo group by driver_name order by total_points desc""")

# COMMAND ----------

display(d2)

# COMMAND ----------

# MAGIC %md
# MAGIC ## window functions

# COMMAND ----------

demo_df =race_results_df.filter("race_year in (2019,2020)")

# COMMAND ----------

display(demo_df)

# COMMAND ----------

demo_grouped_df = demo_df \
.groupBy("race_year","driver_name") \
.agg(sum("points").alias("total_points"),countDistinct("race_name").alias("number_of_races"))
#.orderBy(desc("total_points")) \

# COMMAND ----------

display(demo_grouped_df)

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import desc,rank

driverRankSpec = Window.partitionBy("race_year").orderBy(desc("total_points"))

demo_grouped_df.withColumn("rank",rank().over(driverRankSpec)).show()

# COMMAND ----------


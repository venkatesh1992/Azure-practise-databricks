# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

from pyspark.sql.types import StructType,StructField, IntegerType,StringType,DateType

# COMMAND ----------

races_schema = StructType(fields=[StructField("raceId",IntegerType(),False),
                                 StructField("year",IntegerType(),True),
                                 StructField("round",IntegerType(),True),
                                 StructField("circuitId",IntegerType(),True),
                                 StructField("name",StringType(),True),
                                 StructField("date",DateType(),True),
                                 StructField("time",StringType(),True),
                                 StructField("url",StringType(),True)
                                 ])

# COMMAND ----------

races_df = spark.read.option("header",True).schema(races_schema).csv(f"{raw_folder_path}/races.csv")

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

races_selected_df = races_df.select(col("raceId").alias("race_id"),col("year").alias("race_year"),col("round"),
                                    col("circuitId").alias("circuit_id"),col("name"),col("date"),col("time"))

# COMMAND ----------

from pyspark.sql.functions import to_timestamp,col,concat,lit

# COMMAND ----------

races_timestamp_df=add_ingestion_date(races_selected_df).withColumn("race_time",to_timestamp(concat(col("date"),lit(" "),col("time")),"yyyy-MM-dd HH:mm:ss")).withColumn("data_source",lit(v_data_source))

# COMMAND ----------

races_final_df = races_timestamp_df.select("race_id","race_year","round","circuit_id","name","ingestion_date","race_time","data_source")

# COMMAND ----------

# MAGIC %md
# MAGIC ###we will write partition wise by year

# COMMAND ----------

races_final_df.write.partitionBy("race_year").mode("overwrite").format("parquet").saveAsTable("f1_processed.races")

# COMMAND ----------

display(spark.read.parquet(f"{processed_folder_path}/races"))

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_processed.races;

# COMMAND ----------

dbutils.notebook.exit("Success")
# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

constructor_schema = "constructorId int,constructorRef string,name string,nationality string,url string"

# COMMAND ----------

constructor_df = spark.read.schema(constructor_schema).json(f"{raw_folder_path}/constructors.json")

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,col,lit

# COMMAND ----------

constructor_final_df=add_ingestion_date(constructor_df).select(col("constructorId").alias("constructor_id"),col("constructorRef").alias("constructor_ref"),col("name"),col("nationality"),col("ingestion_date")).withColumn("data_source",lit(v_data_source))

# COMMAND ----------

constructor_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.constructors")

# COMMAND ----------

display(spark.read.parquet(f"{processed_folder_path}/constructors/"))

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_processed.constructors;

# COMMAND ----------

dbutils.notebook.exit("Success")
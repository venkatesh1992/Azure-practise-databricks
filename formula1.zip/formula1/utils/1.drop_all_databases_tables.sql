-- Databricks notebook source
-- MAGIC %md
-- MAGIC # Drop all databases

-- COMMAND ----------

drop database if exists f1_processed CASCADE;

-- COMMAND ----------

create DATABASE IF NOT EXISTS f1_processed
LOCATION "/mnt/formula1dlven/processed"

-- COMMAND ----------

drop database if exists f1_presentation CASCADE;

-- COMMAND ----------

create DATABASE IF NOT EXISTS f1_presentation
LOCATION "/mnt/formula1dlven/presentation"
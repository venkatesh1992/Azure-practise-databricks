-- Databricks notebook source
-- MAGIC %python
-- MAGIC html = """ <h1 style="color:Black;text-align:center;font-family:Ariel">Report on Dominant Formula 1 Drivers</h1>"""
-- MAGIC displayHTML(html)

-- COMMAND ----------

create or replace temp view dominant_teams_vw
as
select team_name,
  count(1) as total_races,
  sum(calculated_points) as total_points,
  avg(calculated_points) as avg_points,
  rank() over(order by avg(calculated_points) desc) as team_rank
from f1_presentation.calculated_race_results
group by team_name
having total_races>=100
order by avg_points desc;

-- COMMAND ----------

select * from dominant_teams_vw;

-- COMMAND ----------

select race_year,
  team_name,
  count(1) as total_races,
  sum(calculated_points) as total_points,
  avg(calculated_points) as avg_points
from f1_presentation.calculated_race_results
where team_name in (select team_name from dominant_teams_vw where team_rank <=5)
group by race_year,team_name
order by race_year,avg_points desc;

-- COMMAND ----------

select race_year,
  team_name,
  count(1) as total_races,
  sum(calculated_points) as total_points,
  avg(calculated_points) as avg_points
from f1_presentation.calculated_race_results
where team_name in (select team_name from dominant_teams_vw where team_rank <=5)
group by race_year,team_name
order by race_year,avg_points desc;

-- COMMAND ----------


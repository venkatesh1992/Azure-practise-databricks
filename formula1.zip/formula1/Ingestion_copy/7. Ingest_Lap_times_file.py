# Databricks notebook source
from pyspark.sql.types import StructType,StructField,StringType,IntegerType,TimestampType

# COMMAND ----------

lap_times_schema = StructType(fields=[StructField("raceId",IntegerType(),True),
                                        StructField("driverId",IntegerType(),True),
                                        StructField("lap",IntegerType(),True),
                                        StructField("position",IntegerType(),True),
                                        StructField("time",StringType(),True),
                                        StructField("milliseconds",IntegerType(),True)
                                       ])

# COMMAND ----------

lap_times_df = spark.read.schema(lap_times_schema).csv("/mnt/formula1dlven/raw/lap_times/lap_times_*.csv")

# COMMAND ----------

display(lap_times_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

lap_times_final_df = lap_times_df.withColumnRenamed("raceId","race_id") \
                                 .withColumnRenamed("driverId","driver_id") \
                                 .withColumn("ingsetion_date",current_timestamp())                                

# COMMAND ----------

display(lap_times_final_df)

# COMMAND ----------

lap_times_final_df.count()

# COMMAND ----------

lap_times_final_df.write.mode("overwrite").parquet("/mnt/formula1dlven/processed/lap_times")

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dlven/processed/lap_times"))

# COMMAND ----------



# COMMAND ----------


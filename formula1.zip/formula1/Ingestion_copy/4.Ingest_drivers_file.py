# Databricks notebook source
from pyspark.sql.types import StructField,StructType,StringType,IntegerType,DateType

# COMMAND ----------

name_schema = StructType(fields=[StructField("forename",StringType(),True),
                                StructField("surname",StringType(),True)])

# COMMAND ----------

drivers_schema = StructType(fields=[StructField("driverId",IntegerType(),True),
                                   StructField("driverRef",StringType(),True),
                                   StructField("number",IntegerType(),True),
                                   StructField("code",StringType(),True),
                                   StructField("name",name_schema),
                                   StructField("dob",DateType(),True),
                                   StructField("nationality",StringType(),True),
                                    StructField("url",StringType(),True)
                                   ])

# COMMAND ----------

drivers_df = spark.read.schema(drivers_schema).json("/mnt/formula1dlven/raw/drivers.json")

# COMMAND ----------

drivers_df.printSchema()

# COMMAND ----------

display(drivers_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,concat,lit,col

# COMMAND ----------

driver_transformed_df = drivers_df.withColumn("name",concat(col("name.forename"),lit(" "),col("name.surname"))).withColumn("ingestion_date",current_timestamp())

# COMMAND ----------

driver_transformed_df.printSchema()

# COMMAND ----------

display(driver_transformed_df)

# COMMAND ----------

drivers_final_df = driver_transformed_df.select(col("driverId").alias("driver_id"),col("driverRef").alias("driver_ref"),
                                               col("number"),col("code"),col("name"),col("dob"),col("nationality"),col("ingestion_date"))

# COMMAND ----------

display(drivers_final_df)

# COMMAND ----------

drivers_final_df.write.mode("overwrite").parquet("/mnt/formula1dlven/processed/drivers")

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dlven/processed/drivers"))

# COMMAND ----------


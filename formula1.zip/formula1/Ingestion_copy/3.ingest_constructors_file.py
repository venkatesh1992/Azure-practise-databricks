# Databricks notebook source
constructor_schema = "constructorId int,constructorRef string,name string,nationality string,url string"

# COMMAND ----------

constructor_df = spark.read.schema(constructor_schema).json("/mnt/formula1dlven/raw/constructors.json")

# COMMAND ----------

display(constructor_df)

# COMMAND ----------

constructor_df.printSchema()

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,col

# COMMAND ----------

constructor_final_df=constructor_df.withColumn("ingestion_date",current_timestamp()).select(col("constructorId").alias("constructor_id"),col("constructorRef").alias("constructor_ref"),col("name"),col("nationality"),col("ingestion_date"))

# COMMAND ----------

display(constructor_final_df)

# COMMAND ----------

constructor_final_df.write.mode("overwrite").parquet("/mnt/formula1dlven/processed/constructor/")

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dlven/processed/constructor/"))

# COMMAND ----------


# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_date","2021-03-28")
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

v_file_date

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType,IntegerType,FloatType

# COMMAND ----------

results_schema = StructType(fields=[StructField("resultId",IntegerType(),True),
                                    StructField("raceId",IntegerType(),True),
                                    StructField("driverId",IntegerType(),True),
                                    StructField("constructorId",IntegerType(),True),
                                    StructField("number",IntegerType(),True),
                                    StructField("grid",IntegerType(),True),
                                    StructField("position",IntegerType(),True),
                                    StructField("positionText",StringType(),True),
                                    StructField("positionOrder",IntegerType(),True),
                                    StructField("points",FloatType(),True),
                                    StructField("laps",IntegerType(),True),
                                    StructField("time",StringType(),True),
                                    StructField("milliseconds",IntegerType(),True),
                                    StructField("fastestLap",IntegerType(),True),
                                    StructField("rank",IntegerType(),True),
                                    StructField("fastestLapTime",StringType(),True),
                                    StructField("fastestLapSpeed",StringType(),True),
                                    StructField("statusId",IntegerType(),True)
                                   ])

# COMMAND ----------

results_df = spark.read.schema(results_schema).json(f"{raw_folder_path}/{v_file_date}/results.json")

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,col,lit

# COMMAND ----------

results_transformed_df=add_ingestion_date(results_df).withColumnRenamed("resultId","result_id").withColumnRenamed("raceId","race_id").withColumnRenamed("driverId","driver_id").withColumnRenamed("constructorId","constructor_id").withColumnRenamed("positionText","position_text").withColumnRenamed("positionOrder","position_order").withColumnRenamed("fastestLap","fastest_lap").withColumnRenamed("fastestLapTime","fastest_lap_time").withColumnRenamed("fastestLapSpeed","fastest_lap_speed").drop("statusId").withColumn("data_source",lit(v_data_source)).withColumn("file_date",lit(v_file_date))

# COMMAND ----------

# MAGIC %md
# MAGIC Deduping results df

# COMMAND ----------

results_final_df = results_transformed_df.dropDuplicates(['race_id','driver_id'])

# COMMAND ----------

# MAGIC %md
# MAGIC alter statement will fail if table doesn't exists, for the first time it will fail
# MAGIC ,to overcome this we will use if statement

# COMMAND ----------

# MAGIC %md
# MAGIC ##Method1

# COMMAND ----------

# for race_id_list in results_transformed_df.select("race_id").distinct().collect():
#   if (spark._jsparkSession.catalog().tableExists("f1_processed.results")):
#     spark.sql(f"alter table f1_processed.results drop if exists partition (race_id={race_id_list.race_id})")
#   #print(race_id_list.race_id)

# COMMAND ----------

# results_transformed_df.write.mode("append").partitionBy("race_id").format("parquet").saveAsTable("f1_processed.results")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Method2

# COMMAND ----------

#overwrite_partitions(results_transformed_df,'f1_processed','results','race_id')

# COMMAND ----------

merge_delta_data(results_final_df,"f1_processed","results",processed_folder_path,
                 merge_condition="tgt.result_id=src.result_id and tgt.race_id=src.race_id",partition_column="race_id")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_processed.results;

# COMMAND ----------

# MAGIC %sql
# MAGIC select race_id,count(1) 
# MAGIC from f1_processed.results
# MAGIC group by race_id
# MAGIC order by race_id desc
# MAGIC ;

# COMMAND ----------

dbutils.notebook.exit("Success")

# COMMAND ----------

# MAGIC %sql
# MAGIC desc history f1_processed.results;

# COMMAND ----------

# MAGIC %sql
# MAGIC select race_id,count(1) 
# MAGIC from f1_processed.results
# MAGIC group by race_id
# MAGIC order by race_id desc
# MAGIC ;

# COMMAND ----------

def rearrange_partition_column(input_df,partition_column):
  column_list=[]
  for column_name in results_final_df.schema.names:
    if column_name!=partition_column:
      column_list.append(column_name)
  column_list.append(partition_column)
  #print(column_list)

  output_df = results_final_df.select(column_list)
  return output_df

# COMMAND ----------

out_df = rearrange_partition_column(results_final_df,"race_id")

# COMMAND ----------

def overwrite_partitions(input_df,database_name,table_name,partition_column):
  spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
  final_df=rearrange_partition_column(input_df,partition_column)
  if(spark._jsparkSession.catalog().tableExists(table_name)):
    final_df.write.mode("overwrite").insertInto(f"{database_name}.{table_name}")
  else:
    final_df.write.mode("overwrite").partitionBy(partition_column).format("parquet").saveAsTable(f"{database_name}.{table_name}")

# COMMAND ----------

overwrite_partitions(results_final_df,'f1_processed','results','race_id')

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists f1_processed.results;

# COMMAND ----------

from delta.tables import deltaTable
if(spark._jsparkSession.catalog().tableExists("f1_processed.results")):
  deltaTable = DeltaTable.forPath(spark,"/mnt/formula1dlven/processed/results")
  deltaTable.alias("tgt").merge(
  results_transformed_df.alias("src"),
    "tgt.result_id=src.result_id") \
  .whenMathedUpdateAll() \
  .whenNotMatchedInsertAll() \
  .execute()    
else:
  results_transformed_df.write.mode("overwrite").partitionBy("race_id").format("delta").saveAsTable("f1_processed.results")

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from f1_processed.results
# MAGIC --WHERE file_date='2021-03-21';

# COMMAND ----------

# MAGIC %sql
# MAGIC select race_id,driver_id,count(1) as dup_count
# MAGIC from f1_processed.results
# MAGIC --where file_date='2021-03-21'
# MAGIC GROUP by race_id,driver_id
# MAGIC having dup_count > 1
# MAGIC ;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_processed.results
# MAGIC where race_id=809 and driver_id=702;

# COMMAND ----------


-- Databricks notebook source
create database if not exists f1_raw;

-- COMMAND ----------

drop table if exists f1_raw.circuits;
create table if not exists f1_raw.circuits(
circuitId int,
circuitRef string,
name string,
location string,
country string,
lat double,
lang double,
alt int,
url string
)
using csv
options(path "/mnt/formula1dlven/raw/circuits.csv",header true);

-- COMMAND ----------

select * from f1_raw.circuits;

-- COMMAND ----------

drop table if exists f1_raw.races;
create table if not exists f1_raw.races(
raceId int,
year int,
round int,
circuitId int,
name string,
date date,
time string,
url string
)
using csv
options(path "/mnt/formula1dlven/raw/races.csv",header true);

-- COMMAND ----------

select  * from f1_raw.races;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##json files

-- COMMAND ----------

drop table if exists f1_raw.constructors;
create table if not exists f1_raw.constructors(
constructorId int,
constructorRef string,
name string,
nationality string,
url string
)
using json
options(path "/mnt/formula1dlven/raw/constructors.json");

-- COMMAND ----------

select * from f1_raw.constructors;

-- COMMAND ----------

drop table if exists f1_raw.drivers;
create table if not exists f1_raw.drivers(
driverId int,
driverRef string,
number int,
code string,
name struct<forename:string,surname:string>,
dob date,
nationality string,
url string
)
using json
options(path "/mnt/formula1dlven/raw/drivers.json");

-- COMMAND ----------

select * from f1_raw.drivers;

-- COMMAND ----------

drop table if exists f1_raw.results;
create table if not exists f1_raw.results(
resultId int,
raceId int,
driverId int,
constructorId int,
number int,
grid int,
position int,
positionText string,
positionOrder int,
points int,
laps int,
time string,
milliseconds int,
fastestLap int,
rank int,
fastestLapTime string,
fastestLapSpeed float,
statusId int
)
using json
options(path "/mnt/formula1dlven/raw/results.json");

-- COMMAND ----------

select * from f1_raw.results;

-- COMMAND ----------

drop table if exists f1_raw.pit_stops;
create table if not exists f1_raw.pit_stops(
raceId int,
driverId int,
stop int,
lap int,
time string,
duration string,
milliseconds int
)
using json
options(path "/mnt/formula1dlven/raw/pit_stops.json", multiLine true);

-- COMMAND ----------

select * from f1_raw.pit_stops;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## tables from multiple files

-- COMMAND ----------

drop table if exists f1_raw.lap_times;
create table if not exists f1_raw.lap_times(
raceId int,
driverId int,
lap int,
position int,
time string,
milliseconds int
)
using csv
options(path "/mnt/formula1dlven/raw/lap_times",header true);

-- COMMAND ----------

select * from f1_raw.lap_times;

-- COMMAND ----------

select count(*) from f1_raw.lap_times;

-- COMMAND ----------

drop table if exists f1_raw.qualifying;
create table if not exists f1_raw.qualifying(
qualifyId int,
raceId int,
driverId int,
constructorId int,
number int,
position int,
q1 string,
q2 string,
q3 string
)
using json
options(path "/mnt/formula1dlven/raw/qualifying",multiLine true);

-- COMMAND ----------

select * from f1_raw.qualifying;

-- COMMAND ----------

desc extended f1_raw.qualifying;

-- COMMAND ----------


# Databricks notebook source
# MAGIC %run "../includes/configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_date","2021-03-28")
v_file_date = dbutils.widgets.get("p_file_date")

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType,IntegerType,TimestampType

# COMMAND ----------

lap_times_schema = StructType(fields=[StructField("raceId",IntegerType(),True),
                                        StructField("driverId",IntegerType(),True),
                                        StructField("lap",IntegerType(),True),
                                        StructField("position",IntegerType(),True),
                                        StructField("time",StringType(),True),
                                        StructField("milliseconds",IntegerType(),True)
                                       ])

# COMMAND ----------

lap_times_df = spark.read.schema(lap_times_schema).csv(f"{raw_folder_path}/{v_file_date}/lap_times/lap_times_*.csv")

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,lit

# COMMAND ----------

lap_times_final_df = add_ingestion_date(lap_times_df).withColumnRenamed("raceId","race_id") \
.withColumnRenamed("driverId","driver_id").withColumn("data_source",lit(v_data_source)).withColumn("file_date",lit(v_file_date))

# COMMAND ----------

overwrite_partitions(lap_times_final_df,'f1_processed','lap_times','race_id')

# COMMAND ----------

display(spark.read.parquet(f"{processed_folder_path}/lap_times"))

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_processed.lap_times;

# COMMAND ----------

# MAGIC %sql
# MAGIC select race_id,count(1) 
# MAGIC from f1_processed.lap_times
# MAGIC group by race_id
# MAGIC order by race_id desc
# MAGIC ;

# COMMAND ----------

dbutils.notebook.exit("Success")
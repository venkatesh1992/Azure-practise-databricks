# Databricks notebook source
spark.read.json("/mnt/formula1dlven/raw/2021-03-21/results.json").createOrReplaceTempView("results_cutover")

# COMMAND ----------

# MAGIC %sql
# MAGIC select raceId,count(1)
# MAGIC from results_cutover
# MAGIC group by raceId
# MAGIC order by raceId desc;

# COMMAND ----------

spark.read.json("/mnt/formula1dlven/raw/2021-03-28/results.json").createOrReplaceTempView("results_cutover_28")

# COMMAND ----------

# MAGIC %sql
# MAGIC select raceId,count(1)
# MAGIC from results_cutover_28
# MAGIC group by raceId
# MAGIC order by raceId desc;

# COMMAND ----------

spark.read.json("/mnt/formula1dlven/raw/2021-04-18/results.json").createOrReplaceTempView("results_cutover_04")

# COMMAND ----------

# MAGIC %sql
# MAGIC select raceId,count(1)
# MAGIC from results_cutover_04
# MAGIC group by raceId
# MAGIC order by raceId desc;

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table f1_processed.results;
# Databricks notebook source
print("I'm from the child notebook")

# COMMAND ----------



# COMMAND ----------

in2=dbutils.widgets.get("input2")

# COMMAND ----------

dbutils.notebook.exit(in2)

# COMMAND ----------


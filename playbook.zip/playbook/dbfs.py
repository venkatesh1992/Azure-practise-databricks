# Databricks notebook source
# MAGIC %fs
# MAGIC ls

# COMMAND ----------


# Databricks notebook source
# MAGIC %md
# MAGIC # Notebooks Introduction
# MAGIC * UI Commands
# MAGIC * Magic Commands

# COMMAND ----------

msg = 'Hello world'
print(msg)

# COMMAND ----------

print(msg)

# COMMAND ----------

# MAGIC %sql
# MAGIC select "Hello"

# COMMAND ----------

# MAGIC %sql
# MAGIC show databases;

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables;

# COMMAND ----------

# MAGIC %scala
# MAGIC val a=10
# MAGIC println(a)

# COMMAND ----------

# MAGIC %fs
# MAGIC ls

# COMMAND ----------

# MAGIC %fs
# MAGIC ls dbfs:/databricks-datasets/

# COMMAND ----------

# MAGIC %fs
# MAGIC ls dbfs:/databricks-datasets/COVID/

# COMMAND ----------

# MAGIC %fs
# MAGIC ls dbfs:/databricks-datasets/COVID/USAFacts/

# COMMAND ----------

# MAGIC %fs
# MAGIC head dbfs:/databricks-datasets/COVID/USAFacts/covid_confirmed_usafacts.csv

# COMMAND ----------

# MAGIC %sh
# MAGIC ps

# COMMAND ----------

# MAGIC %md
# MAGIC # Databricks Utilities
# MAGIC * file system utilities - working with file sysytem using %fs
# MAGIC * notebook workflow utilities - calling one notebook from another,it will allow cascading
# MAGIC * Widget - paasing parameters to the notebook
# MAGIC * Secret - reading secrets from the keyvault
# MAGIC * Library - instead of installing libraries manually, we will do with magic commands like %pip

# COMMAND ----------

# MAGIC %fs
# MAGIC ls

# COMMAND ----------

dbutils.fs.ls('/')

# COMMAND ----------

# MAGIC %md
# MAGIC * with this we can combine both file sysytem and python by using dbutils

# COMMAND ----------

for f in dbutils.fs.ls('/'):
  print(f)

# COMMAND ----------

dbutils.fs.help()

# COMMAND ----------

dbutils.fs.help('mount')

# COMMAND ----------

dbutils.notebook.help()

# COMMAND ----------

dbutils.notebook.run('./child_notebook',30)

# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("Input"," ","Set input value")

# COMMAND ----------

input_param=dbutils.widgets.get("Input")

# COMMAND ----------

print(input_param)

# COMMAND ----------

in2=dbutils.notebook.run('./child_notebook',30,{"input2":"Called from main notebook"})

# COMMAND ----------

print(in2)

# COMMAND ----------

# MAGIC %pip install pandas

# COMMAND ----------

